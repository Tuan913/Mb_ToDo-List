import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Switch,
  Picker,
} from 'react-native';

const TodoApp = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [filterDone, setFilterDone] = useState('all');
  const [searchText, setSearchText] = useState('');

  const addTask = () => {
    if (newTask.trim() !== '') {
      setTasks([...tasks, { id: Date.now(), text: newTask, done: false, timestamp: new Date() }]);
      setNewTask('');
    }
  };

  const toggleDone = (id) => {
    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, done: !task.done, timestamp: new Date() } : task
    );
    setTasks(updatedTasks);
  };

  const deleteTask = (id) => {
    const updatedTasks = tasks.filter((task) => task.id !== id);
    setTasks(updatedTasks);
  };

  const renderTask = ({ item }) => {
    if (
      ((filterDone === 'all') ||
        (filterDone === 'done' && item.done) ||
        (filterDone === 'notDone' && !item.done)) &&
      (item.text.toLowerCase().includes(searchText.toLowerCase()) || searchText === '')
    ) {
      return (
        <View style={[styles.taskContainer, item.done && styles.doneTask]}>
          <Text style={[styles.taskText, item.done && styles.doneTaskText]} numberOfLines={2} ellipsizeMode="tail">
            {item.text}
          </Text>
          <Switch value={item.done} onValueChange={() => toggleDone(item.id)} />
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() => deleteTask(item.id)}
          >
            <Text style={styles.deleteButtonText}>DELETE</Text>
          </TouchableOpacity>
          <Text style={styles.timestamp}>{formatTimestamp(item.timestamp)}</Text>
        </View>
      );
    } else {
      return null;
    }
  };

  const formatTimestamp = (timestamp) => {
    const options = { year: 'numeric', month: 'numeric', day: 'numeric' };
    return new Date(timestamp).toLocaleDateString(undefined, options);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>TODO LIST </Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Add a new task"
          value={newTask}
          onChangeText={(text) => setNewTask(text)}
        />
        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>ADD ITEM</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.filterContainer}>
        <Text>Show:</Text>
        <Picker
          style={{ flex: 1 }}
          selectedValue={filterDone}
          onValueChange={(itemValue) => setFilterDone(itemValue)}
        >
          <Picker.Item label="All" value="all" />
          <Picker.Item label="Done" value="done" />
          <Picker.Item label="Not Done" value="notDone" />
        </Picker>
      </View>
      <TextInput
        style={styles.input}
        placeholder="Search..."
        value={searchText}
        onChangeText={(text) => setSearchText(text)}
      />
      <FlatList
        data={tasks}
        renderItem={renderTask}
        keyExtractor={(item) => item.id.toString()}
        style={styles.taskList}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    backgroundColor: '#552434',
    paddingBottom: 28,
    color: 'white',
    padding: 20,
  },
  inputContainer: {
    flexDirection: 'column',
    marginBottom: 16,
  },
  input: {
    height: 35,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 8,
    marginBottom: 8,
  },
  addButton: {
    backgroundColor: 'brown',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  taskList: {
    marginTop: 10,
    backgroundColor: '#ecf0f1',
    borderRadius: 8,
  },
  taskContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 4,
    padding: 12,
    marginBottom: 8,
  },
  taskText: {},
  doneTask: {
    backgroundColor: '#dfe6e9',
  },
  doneTaskText: {
    textDecorationLine: 'underline',
    color: 'red',
  },
  deleteButton: {
    backgroundColor: 'red',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
    marginLeft: 8,
  },
  deleteButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  timestamp: {
    marginLeft: 10,
  },
});

export default TodoApp;